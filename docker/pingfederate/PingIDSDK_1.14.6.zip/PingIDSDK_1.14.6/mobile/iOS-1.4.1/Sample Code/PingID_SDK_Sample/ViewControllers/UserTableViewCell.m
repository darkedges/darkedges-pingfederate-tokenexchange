//
//  UserTableViewCell.m
//  PingID_SDK_Sample
//
//  Created by Segev Sherry on 11/5/18.
//  Copyright © 2018 Ping Identity. All rights reserved.
//

#import "UserTableViewCell.h"

@implementation UserTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
