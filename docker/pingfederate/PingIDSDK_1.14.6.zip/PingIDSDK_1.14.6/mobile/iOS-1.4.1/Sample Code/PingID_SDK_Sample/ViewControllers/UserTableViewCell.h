//
//  UserTableViewCell.h
//  PingID_SDK_Sample
//
//  Created by Segev Sherry on 11/5/18.
//  Copyright © 2018 Ping Identity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *usernameLbl;

@end
